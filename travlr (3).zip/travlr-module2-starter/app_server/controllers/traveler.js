/**
 * Traveler controller
 * Responsible for serving traveler-related pages/data using MVC.
 */

const trips = [
  { code: 'BALI',  name: 'Bali Escape',      price: 1299, nights: 7,  tags: ['beach','relax'] },
  { code: 'ALPS',  name: 'Swiss Alps Trek',  price: 1799, nights: 10, tags: ['hiking','snow'] },
  { code: 'NYC',   name: 'NYC Weekend',      price: 699,  nights: 3,  tags: ['city','food'] }
];

const list = (req, res) => {
  res.render('pages/trips', {
    title: 'Travlr | Trips',
    navActive: 'trips',
    trips
  });
};

const detail = (req, res) => {
  const code = (req.params.code || '').toUpperCase();
  const trip = trips.find(t => t.code === code);
  if (!trip) {
    return res.status(404).render('pages/error', { title: 'Not found', status: 404, message: 'Trip not found' });
  }
  res.render('pages/trip-detail', {
    title: `Travlr | ${trip.name}`,
    navActive: 'trips',
    trip
  });
};

module.exports = { list, detail };
