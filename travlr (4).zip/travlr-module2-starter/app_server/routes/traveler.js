const express = require('express');
const router = express.Router();
const travelerCtrl = require('../controllers/traveler');

/* GET list of trips (aligns with wireframe "Trips" page). */
router.get('/', travelerCtrl.list);

/* GET individual trip detail (example of a second page you can build out). */
router.get('/:code', travelerCtrl.detail);

module.exports = router;
