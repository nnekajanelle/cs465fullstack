# Travlr Getaways — Module 2 (MVC + Handlebars)

This starter shows the expected **MVC structure** with **routes**, **controllers**, and **HBS templates**.

## Run locally
```bash
npm install
npm run dev   # or: npm start
# open http://localhost:3000
```

## Where things live
- `app.js` — registers Handlebars, static files, and routers
- `app_server/routes/` — Express route files
- `app_server/controllers/` — controller functions (e.g., `traveler.list`)
- `app_server/views/` — HBS views
  - `layouts/main.hbs` — base layout
  - `partials/` — header/nav/footer
  - `pages/` — page templates (home, trips, trip-detail, error)
- `public/` — static assets (css, images)

## Rubric mapping
- **MVC architecture**: controllers + routes + views folders are in `app_server/`
- **Routes & controllers**: `/` (home) and `/traveler` (trips) plus `/traveler/:code`
- **HBS directives**: `{{#each}}`, `{{#if}}`, custom helper `eq`, partials, layout
- **Render test**: pages render dynamic data from the controller

## Submit
Zip the folder you worked in (it must include `app_server/` and updated `app.js`).

## Git (example)
```bash
git checkout -b module2
git add .
git commit -m "Module 2: MVC + HBS refactor"
git push -u origin module2
```
