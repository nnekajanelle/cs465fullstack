const exphbs = require('express-handlebars');
const travelerRouter = require('./app_server/routes/traveler');

// app.js
require('./db');

const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');


const indexRouter = require('./app_server/routes/index');
const apiRouter = require('./app_api/routes/index'); // <-- add this

const app = express();

// ... logger, parsers, etc.

app.use('/', indexRouter);
app.use('/api', apiRouter); // <-- API mounted here

// error handlers, module.exports = app, etc.

// -------------------- View engine (HBS) --------------------
app.engine('hbs', exphbs.engine({
  extname: 'hbs',
  defaultLayout: 'main',
  layoutsDir: path.join(__dirname, 'app_server', 'views', 'layouts'),
  partialsDir: path.join(__dirname, 'app_server', 'views', 'partials'),
  helpers: {
    eq: (a, b) => a === b
  }
}));
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// -------------------- Middleware --------------------
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// -------------------- Routes --------------------
app.use('/', indexRouter);
app.use('/traveler', travelerRouter);
app.use('/api', apiRouter);


// -------------------- Error handling --------------------
app.use(function(req, res, next) {
  next(createError(404));
});

app.use(function(err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  res.status(err.status || 500);
  res.render('pages/error', { title: 'Error', status: err.status || 500, message: err.message });
});

module.exports = app;
