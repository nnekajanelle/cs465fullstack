// app_api/controllers/trips.js
const Trip = require('../models/travlr');

// GET /api/trips - list all trips
const tripsList = async (req, res) => {
  try {
    const trips = await Trip.find({}).exec();
    return res.status(200).json(trips);
  } catch (err) {
    console.error('Error retrieving trips', err);
    return res.status(500).json({
      message: 'Error retrieving trips'
    });
  }
};

// GET /api/trips/:tripCode - single trip by code
const tripsFindCode = async (req, res) => {
  const tripCode = req.params.tripCode;

  try {
    const trip = await Trip.findOne({ code: tripCode }).exec();

    if (!trip) {
      return res.status(404).json({
        message: `Trip with code ${tripCode} not found`
      });
    }

    return res.status(200).json(trip);
  } catch (err) {
    console.error('Error retrieving trip', err);
    return res.status(500).json({
      message: 'Error retrieving trip'
    });
  }
};

module.exports = {
  tripsList,
  tripsFindCode
};

