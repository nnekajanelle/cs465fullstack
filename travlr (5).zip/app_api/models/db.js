// db.js
const mongoose = require('mongoose');

let dbURI = 'mongodb://127.0.0.1/travlr';

if (process.env.NODE_ENV === 'production') {
  dbURI = process.env.MONGODB_URI || dbURI;
}

mongoose.connect(dbURI);

mongoose.connection.on('connected', () => {
  console.log(`Mongoose connected to ${dbURI}`);
});

mongoose.connection.on('error', err => {
  console.log('Mongoose connection error:', err);
});

mongoose.connection.on('disconnected', () => {
  console.log('Mongoose disconnected');
});

// Load models (path is FROM ROOT now)
require('./app_api/models/travlr');
