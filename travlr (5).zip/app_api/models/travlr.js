const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({
  code: { type: String, required: true },
  name: { type: String, required: true },
  length: Number,
  price: Number,
  description: String,
  cover: String,
  tags: [String]
});

mongoose.model('Trip', tripSchema);
