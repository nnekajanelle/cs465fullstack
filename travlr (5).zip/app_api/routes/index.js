// app_api/routes/index.js
const express = require('express');
const router = express.Router();

const tripsController = require('../controllers/trips');

// /api/trips - list all trips
router.get('/trips', tripsController.tripsList);

// /api/trips/:tripCode - single trip by code
router.get('/trips/:tripCode', tripsController.tripsFindCode);

module.exports = router;
