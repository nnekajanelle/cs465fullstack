const tripsController = require('../controllers/trips');

const express = require('express');
const router = express.Router();

/* GET home page. */
router.get('/', function(req, res) {
  res.render('pages/home', { title: 'Travlr | Home', navActive: 'home' });
});

// API routes for trips
router.get('/api/trips', tripsController.tripsList);
router.get('/api/trips/:tripCode', tripsController.tripsFindByCode);

module.exports = router;
