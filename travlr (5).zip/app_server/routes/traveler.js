const express = require('express');
const router = express.Router();

const travelerCtrl = require('../controllers/traveler');

router.get('/', travelerCtrl.list);
router.get('/:code', travelerCtrl.detail);

module.exports = router;
