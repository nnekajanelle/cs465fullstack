const createError = require('http-errors');
const express = require('express');
const path = require('path');
const cookieParser = require('cookie-parser');
const logger = require('morgan');
const exphbs = require('express-handlebars');

// Routes
const indexRouter = require('./app_server/routes/index');
const travelerRouter = require('./app_server/routes/traveler');

const app = express();

// -------------------- View engine (HBS) --------------------
app.engine('hbs', exphbs.engine({
  extname: 'hbs',
  defaultLayout: 'main',
  layoutsDir: path.join(__dirname, 'app_server', 'views', 'layouts'),
  partialsDir: path.join(__dirname, 'app_server', 'views', 'partials'),
  helpers: {
    eq: (a, b) => a === b
  }
}));
app.set('views', path.join(__dirname, 'app_server', 'views'));
app.set('view engine', 'hbs');

// -------------------- Middleware --------------------
app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

// -------------------- Routes --------------------
app.use('/', indexRouter);
app.use('/traveler', travelerRouter);

// -------------------- Error handling --------------------
app.use(function(req, res, next) {
  next(createError(404));
});

app.use(function(err, req, res, next) {
  res.locals.message = err.message;
  res.locals.error = req.app.get('env') === 'development' ? err : {};
  res.status(err.status || 500);
  res.render('pages/error', { title: 'Error', status: err.status || 500, message: err.message });
});

module.exports = app;
